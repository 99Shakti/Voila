#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import streamlit as st
st.title('Uber pickups in NYC')

add_selectbox = st.sidebar.selectbox(
    "How would you like to be contacted?",
    ("Email", "Home phone", "Mobile phone")
)
streamlit = "cool"
theming = "fantastic"
both = "💥"



import json

import requests  # pip install requests
import streamlit as st  # pip install streamlit
from streamlit_lottie import st_lottie  # pip install streamlit-lottie

# GitHub: https://github.com/andfanilo/streamlit-lottie
# Lottie Files: https://lottiefiles.com/

def load_lottiefile(filepath: str):
    with open(filepath, "r") as f:
        return json.load(f)


def load_lottieurl(url: str):
    r = requests.get(url)
    if r.status_code != 200:
        return None
    return r.json()
    

lottie_coding = load_lottiefile("lottiefile.json")  # replace link to local lottie file
lottie_hello = load_lottieurl("https://assets5.lottiefiles.com/packages/lf20_gjsy1lag.json")

st_lottie(
    lottie_hello,
    speed=.5,
    reverse=False,
    loop=True,
    quality="high", # medium ; high
    #renderer="svg", # canvas
    height=500,
    width=500,
    key=None,
)
   