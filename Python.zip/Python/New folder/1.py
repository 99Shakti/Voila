#!/usr/bin/env python
# coding: utf-8

# In[ ]:
html_temp = """
    <div style="background-color:red;padding:10px">
    <h1 style="color:white;text-align:center;">Streamlit Bank Authenticator ML App </h2>
    </div>
    """

import numpy as np
import pickle
import pandas as pd
import streamlit as st

st.title("Hi")

pickle_in = open("model_pkl","rb")
classifier=pickle.load(pickle_in)
#loaded_model = pickle.load(open("model_pkl", 'rb'))
def welcome():
    return "Welcome All"


def predict_note_authentication(MSSubClass,MSZoning,Neighborhood,OverallQual,YearRemodAdd,
       RoofStyle, BsmtQual, BsmtExposure,HeatingQC, CentralAir,
       fstFlrSF, GrLivArea, BsmtFullBath, KitchenQual, Fireplaces,
       FireplaceQu, arageType,GarageFinish, GarageCars,PavedDrive,
       SaleCondition):
    pass

    prediction=classifier.predict([[MSSubClass,MSZoning,Neighborhood,OverallQual,YearRemodAdd,
       RoofStyle, BsmtQual, BsmtExposure,HeatingQC, CentralAir,
       fstFlrSF, GrLivArea, BsmtFullBath, KitchenQual, Fireplaces,
       FireplaceQu, arageType,GarageFinish, GarageCars,PavedDrive,
       SaleCondition]])
    print(prediction)
    return prediction



def main():
    st.title("Bank Authenticator")
    html_temp = """
    <div style="background-color:red;padding:10px">
    <h2 style="color:white;text-align:center;">Streamlit Bank Authenticator ML App </h2>
    </div>
    """

    
    st.markdown(html_temp,unsafe_allow_html=True)
    MSSubClass=                st.number_input("MSSubClass")
    MSZoning=                  st.number_input("MSZoning")
    Neighborhood =             st.number_input("Neighborhood")
    OverallQual =              st.number_input("OverallQual")
    YearRemodAdd =             st.number_input("YearRemodAdd")
    RoofStyle =                st.number_input("RoofStyle")
    BsmtQual =                 st.number_input("BsmtQual")
    BsmtExposure =             st.number_input("BsmtExposure")
    HeatingQC =                st.number_input("HeatingQC ")
    CentralAir =               st.number_input("CentralAir")
    fstFlrSF =                 st.number_input("fstFlrSF")
    GrLivArea =                st.number_input("GrLivArea")
    BsmtFullBath =             st.number_input("BsmtFullBath")
    KitchenQual=               st.number_input("KitchenQual")
    Fireplaces =               st.number_input("Fireplaces")
    FireplaceQu =              st.number_input("FireplaceQu")
    GarageType =               st.number_input("GarageType")
    GarageFinish =             st.number_input("GarageFinish")
    GarageCars=                st.number_input("GarageCars")
    PavedDrive =               st.number_input("PavedDrive")
    SaleCondition =            st.number_input("SaleCondition")
    
    
    result=""
    if st.button("Predict"):
        result=predict_note_authentication(MSSubClass,MSZoning,Neighborhood,OverallQual,YearRemodAdd,
       RoofStyle, BsmtQual, BsmtExposure,HeatingQC, CentralAir,
       fstFlrSF, GrLivArea, BsmtFullBath, KitchenQual, Fireplaces,
       FireplaceQu,GarageType,GarageFinish,GarageCars,PavedDrive,
       SaleCondition)
    st.success('The output is {}'.format(result))
    if st.button("About"):
        st.text("Lets LEarn")
        st.text("Built with Streamlit")

if __name__=='__main__':
    main()