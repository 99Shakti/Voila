#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
from pathlib import Path
import shutil
import time
from pathlib import Path
from zipfile import ZipFile
Unilever_source_path = 'S:/UNILEVER/' # this is the Unilever path where we found the Zip files
destination_1_main_folder = 'S:/UNILEVER_SDRIVE/Main/'
allfiles_unilver_source_folder = os.listdir(Unilever_source_path)
for i in range(1):
    if len(allfiles_unilver_source_folder)==0:
            print('Unilever Folder is Empty::')
            print(allfiles_unilver_source_folder)
            time.sleep(7)
            break
    else:
        #------------step- 1--this program first delete the old file in main if any exits----------------
        destination_1_main_folder = 'S:/UNILEVER_SDRIVE/Main/'
        for filename in os.listdir(destination_1_main_folder):
            allfiles_unilver_source_folder
            file_path = os.path.join(destination_1_main_folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))
           #-------------------1----step---is end
        
        #---now ---2--- step is start that copy all three destination drive 
        Unilever_source_path = 'S:/UNILEVER/' #this is the Unilever path where we found the Zip files
        destination_1_main_folder = 'S:/UNILEVER_SDRIVE/Main/'
        destination_OtherDrive_1='T:/UNILEVER/'
        destination_OtherDrive_2='U:/UNILEVER/'
        allfiles = os.listdir(Unilever_source_path)
        for fname in allfiles:
            shutil.copy2(os.path.join(Unilever_source_path,fname), destination_OtherDrive_1)
            shutil.copy2(os.path.join(Unilever_source_path,fname), destination_OtherDrive_2)
        for f in allfiles:
            os.rename(Unilever_source_path + f, destination_1_main_folder + f)
            
        #---------step-2 is end all three drive file updated---------------------    
        # ------now step-3 is start first in backup old file is deleted and past the unzip flolder files    
            
        #destination_Back_folder_path = 'S:/UNILEVER_SDRIVE/Backup/'
        #for filename in os.listdir(destination_Back_folder_path):
            #file_path = os.path.join(destination_Back_folder_path, filename)
             #try:
               # if os.path.isfile(file_path) or os.path.islink(file_path):
                #    os.unlink(file_path)
                #elif os.path.isdir(file_path):
                 #   shutil.rmtree(file_path)
            #except Exception as e:
             #   print('Failed to delete %s. Reason: %s' % (file_path, e))
                
        destination_1_main_folder=os.listdir('S:/UNILEVER_SDRIVE/Main/')
        print(destination_1_main_folder)
        from zipfile import ZipFile
        os.chdir('S:/UNILEVER_SDRIVE/Main/')
        
        
        # Target directory
        extract_dir = "S:/UNILEVER_SDRIVE/Unzip/"
        print('Unzipping All Filees are processing............')
        print('Please Wait...........')
        for i in range(len(destination_1_main_folder)):
            print(destination_1_main_folder[i])
            filename = "S:/UNILEVER_SDRIVE/Main/"+destination_1_main_folder[i]
            shutil.unpack_archive(filename, extract_dir)
            #filee[i].extractall('S:/TEMP/Backup/')
            #with ZipFile(filee[i]) as zipObj:'
        
        source = 'S:/UNILEVER_SDRIVE/Unzip/'
        destination = 'S:/UNILEVER_SDRIVE/Backup/'
        allfiles = os.listdir(source)
        for fname in allfiles:
            shutil.copy2(os.path.join(source,fname), destination) 
        destination_1_main = 'S:/UNILEVER_SDRIVE/Main/'
        for f in os.listdir(destination_1_main):
            os.remove(os.path.join(destination_1_main, f))
        
        print('All Files Are Unzip Processed.........................')
        time.sleep(7) 
        print('Done Thank You')

