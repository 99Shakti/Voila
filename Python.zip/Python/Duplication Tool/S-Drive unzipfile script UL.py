import os
from pathlib import Path
import shutil
source = 'S:/TEMP/UNILEVER/'
destination = 'S:/TEMP/Main/'
allfiles = os.listdir(source)
for i in range(1):
    if len(allfiles)==0:
        print('Unilever Folder is Empty::')
        import time
        time.sleep(7)
        break
    else:
        folder = 'S:/TEMP/Main/'
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))
        
        source = 'S:/TEMP/UNILEVER/'
        destination = 'S:/TEMP/Main/'
        allfiles = os.listdir(source)
        for f in allfiles:
            os.rename(source + f, destination + f)
            
        folder = 'S:/TEMP/Backup/'
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))
        
        
        filee=os.listdir('S:/TEMP/Main/')
        print(filee)
        from zipfile import ZipFile
        os.chdir('S:/TEMP/Main/')
        
        
        # Target directory
        extract_dir = "S:/TEMP/Unzip/"
        print('Unzipping All Filees are processing............')
        print('Please Wait...........')
        for i in range(len(filee)):
            print(filee[i])
            filename = "S:/TEMP/Main/"+filee[i]
            shutil.unpack_archive(filename, extract_dir)
            #filee[i].extractall('S:/TEMP/Backup/')
            #with ZipFile(filee[i]) as zipObj:'
        source = 'S:/TEMP/Unzip/'
        destination = 'S:/TEMP/Backup/'
        allfiles = os.listdir(source)
        for f in allfiles:
            os.rename(source + f, destination + f)
        
        print('All Files Are Unzip Processed Done Thank You')
        import time
        time.sleep(7)